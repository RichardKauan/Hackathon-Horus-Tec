<meta charset="utf-8">
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Registrado concluído</title>

    <!-- CSS Application -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">

    <!-- JS Application -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
	    <!-- Home(Title) -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 id="title">Patriani</h1>
            </div>
        </div>
    </div>
    <!-- End(Title) -->

    <!-- Home(NavBar) -->
    <ul id="nav">
        <li id="bar1"><a href="home.html">Home</a></li>
        <li id="bar2"><a href="evento.html">Eventos</a></li>
        <li id="bar3"><a href="mapa.html">Mapa</a></li>
        <li id="bar4"><a href="registro.html">Registrar Local</a></li>
    </ul>
    <!-- End(NavBar) -->
    <div class="container">
<h2>Registro concluido com sucesso, agradecemos sua contribuição, sua localização estará no mapa principal em breve</h2>
<a href="home.html"><button class="form-control" class="btn btn-success">Voltar para a Home</button></a>
</div>
<br>
    <!-- Home (Copyright) -->    
    <div class="footer-copyright text-center py-3">
            © 2019 Copyright: HORUS TECH
        </div>
    <!-- End (Copyright) -->
</body>
</html>
<?php 
	
 ?>